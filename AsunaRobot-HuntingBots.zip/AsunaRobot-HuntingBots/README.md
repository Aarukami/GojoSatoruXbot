## 🌟[AsunaRobot](https://telegram.dog/My_Asuna_Robot)🌟
### Telegram Group Manager Bot Written In Python Using Telethon+Pyrogram.

<p align="center">
    <a href="https://github.com/HuntingBots/AsunaRobot/stargazers"><img src="https://img.shields.io/github/stars/HuntingBots/AsunaRobot?label=Stars&style=flat-square&logo=github&color=teal" alt="Stars" /></a>
</p>

 <a href="http://t.me/My_Asuna_Robot" alt="AsunaRobot"> <img src="https://img.shields.io/badge/%F0%9F%A4%96%20-AsunaRobot On Telegram!-blue" /> </a>


<p align="center">
    <a href="https://github.com/HuntingBots/AsunaRobot"> <img src="https://img.shields.io/github/repo-size/HuntingBots/AsunaRobot?color=fuchsia&logo=github&logoColor=red&style=for-the-badge" /></a>
    <a href="https://github.com/HuntingBots/AsunaRobot/commits/prince"> <img src="https://img.shields.io/github/last-commit/HuntingBots/AsunaRobot?color=indigo&logo=github&logoColor=green&style=for-the-badge" /></a>
    <a href="https://github.com/HuntingBots/AsunaRobot/issues"> <img src="https://img.shields.io/github/issues/HuntingBots/AsunaRobot?color=green&logo=github&logoColor=yellow&style=for-the-badge" /></a>
    <a href="https://github.com/HuntingBots/AsunaRobot/network/members"> <img src="https://img.shields.io/github/forks/HuntingBots/AsunaRobot?color=olive&logo=github&logoColor=maroon&style=for-the-badge" /></a>  
    <a href="https://pypi.org/project/telethon/"> <img src="https://img.shields.io/pypi/v/telethon?color=aqua&label=telethon&logo=python&logoColor=blue&style=for-the-badge" /></a>
</p>

<p align="center">
  <img src="https://telegra.ph/file/4977514f30ff13c11363b.jpg">
</p>

## Requirements

- PTB >= 13.6
- A [REDIS_URL](https://redis.com).
- A [Telegram bot token](https://t.me/botfather).
- A [MongoDB URI](https://telegra.ph/How-To-get-Mongodb-URI-04-06).


# Run On Heroku

### Easiest Way To Deploy On Heroku 


[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/HuntingBots/AsunaRobot/)

```

This Bot is Created by The_Ghost_Hunter, If your kanging this without fork at least give a credit to get a smile of my hard work.
 
👉 YoneRobot
👉 SaitamaRobot 
👉 TheRealPhoenixBot
👉 DaisyX 
👉 WilliamButcherBot


$ git clone https://github.com/HuntingBots/AsunaRobot

```



## Note


* [The Ghost Hunter](https://telegram.dog/The_Ghost_Hunter)
* [Support](https://telegram.dog/AsunaRobotSupport)
* [Discussion](https://telegram.dog/helpcentrebot1)
* [Second Group](https://telegram.dog/fire_world_entertainment)
